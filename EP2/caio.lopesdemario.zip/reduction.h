#include "helperFunctions.h"

int *reduceOnGPU(int *matrixList, int matrixAmount);