double sumValueRowWise(int**M, int width, int height);
double sumValueColumnWise(int**M, int width, int height);