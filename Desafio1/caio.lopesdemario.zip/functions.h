double compareValues(int*A, int n);
double sortAndCompareValues(int*A, int n);
double predictableIf(void);
double unpredictableIf(void);